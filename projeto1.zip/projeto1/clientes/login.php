<?php

session_start();


// Processar login
if(isset($_POST['login'])){
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $stmt = $conn->prepare("SELECT id, nome, senha FROM clientes WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows === 1){
        $vendedor = $result->fetch_assoc();
        if(password_verify($senha, $vendedor['senha'])){
            $_SESSION['clientes_id'] = $vendedor['id'];
            $_SESSION['clientes_nome'] = $vendedor['nome'];
            
            exit();
        } else {
            $erro = "Senha incorreta!";
        }
    } else {
        $erro = "Email não encontrado!";
    }
}
?>


<div class="container">
    <h2>Login Cliente</h2>
    <?php if(isset($erro)) echo "<p style='color:red;'>$erro</p>"; ?>
    <form method="POST" action="?pg=carros/view">
        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Senha:</label>
        <input type="password" name="senha" required>

        <button type="submit">Entrar</button>
    </form>
    <p>Não possui cadastro? <a href="register.php">Cadastrar</a></p>
</div>


