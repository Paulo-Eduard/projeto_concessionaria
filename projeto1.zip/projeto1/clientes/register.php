

<div class="container">
    <h2>Cadastro de Cliente</h2>
    <?php if(isset($erro)) echo "<p style='color:red;'>$erro</p>"; ?>
    <form method="POST" action="?pg=clientes/registrado">
        <label>Nome:</label>
        <input type="text" name="nome" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Senha:</label>
        <input type="password" name="senha" required>

        <button type="submit">Cadastrar</button>
    </form>
    <p>Já possui cadastro? <a href="login.php">Login</a></p>
</div>

