</main>
<footer>
    <p>© <?php echo date("Y"); ?> Concessionária. Todos os direitos reservados.</p>
</footer>
</body>
</html>
