<div class="container">
    <h2>Bem-vindo à Concessionária</h2>
    <p>Cadastre-se ou faça login para ver e comprar carros.</p>
    <div style="display:flex; gap:20px; justify-content:center; margin-top:20px;">
        <a class="btn" href="?pg=clientes/register">Cadastrar Cliente</a>
        <a class="btn" href="?pg=clientes/login">Login Cliente</a>
        <a class="btn" href="?pg=vendedores/register">Cadastrar Vendedor</a>
        <a class="btn" href="?pg=vendedores/login">Login Vendedor</a>
    </div>
</div>