<?php

require_once "admin/config.inc.php";

$id = $_REQUEST['id'];
$sql = "DELETE FROM carros WHERE id = '$id'";

if(mysqli_query($conexao, $sql)){
    echo "<br><h2 style='margin:45px 0'>Carro Excluido com Sucesso.</h2>";
    echo "<a class='btn' href='?pg=carros/list'>Voltar</a>";
}else{
    echo "<br><h2 style='margin:45px 0'>Erro ao excluir carro.</h2>";
    echo "<a class='btn' href='?pg=carros/list'>Voltar</a>";
}
?>
