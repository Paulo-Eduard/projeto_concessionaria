<?php

require_once 'admin/config.inc.php';

$sql = "SELECT * FROM carros";
$resultado = mysqli_query($conexao, $sql);
?>

<div class="container">
    <h2>Meus Carros</h2>

    <a href="?pg=carros/add" class="btn add-btn">Adicionar Novo Carro</a>

        <table>
            <thead>
                <tr>
                    <th>Imagem</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Preço</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while($dados = mysqli_fetch_array($resultado)){?>
                    <tr>
                    <td><img src='<?php echo $dados['imagem']; ?>' width="100px" height="100px"></td>
                    <td><?php echo htmlspecialchars($dados['marca']); ?></td>
                    <td><?php echo htmlspecialchars($dados['modelo']); ?></td>
                    <td>R$ <?php echo number_format($dados['preco'],2,',','.'); ?></td>
                    <td>
                        <?php echo "<a href='?pg=carros/edit&id=$dados[id]' class='btn btn-primary'>Editar</a>
                        <a href='?pg=carros/delete&id=$dados[id]' class='btn btn-danger' onclick='return confirm('Deseja realmente excluir?');>Excluir</a>
                    "?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>

</div>

