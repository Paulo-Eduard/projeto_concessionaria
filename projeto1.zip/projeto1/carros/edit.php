<?php

require 'admin/config.inc.php';

// Busca o carro
$id = $_REQUEST["id"];
$sql = "SELECT * FROM carros WHERE id = '$id'";
$resultado = mysqli_query($conexao, $sql);

if(mysqli_num_rows($resultado) > 0){
    while($dados = mysqli_fetch_array($resultado)){
        $modelo = $dados["modelo"];
        $marca = $dados["marca"];
        $preco = $dados["preco"];
        $imagem = $dados["imagem"];
        $id = $dados["id"];
    }


?>



<div class="container">
    <h2>Editar Carro</h2>
    <form method="POST" enctype="multipart/form-data" action="?pg=carros/carros-edit">
        <input type="hidden" name="id" value="<?=$id?>">
        <label>Modelo:</label>
        <input type="text" name="modelo" value="<?=$modelo?>" required>

        <label>Marca:</label>
        <input type="text" name="marca" value="<?=$marca?>" required>

        <label>Preço:</label>
        <input type="number" step="0.01" name="preco" value="<?=$preco?>" required>

        <label>Imagem:</label>
        <input type="text" name="imagem" value="<?=$imagem?>">
        

        <button type="submit">Atualizar</button>
    </form>
</div>


<?php

}else{
    echo "<h2>Nenhum carro encontrado.</h2>";
}

?>