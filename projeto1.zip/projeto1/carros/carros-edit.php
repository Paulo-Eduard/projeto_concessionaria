<?php

require_once 'admin/config.inc.php';
// Atualiza
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $modelo = $_POST['modelo'];
    $marca = $_POST['marca'];
    $preco = $_POST['preco'];
    $imagem = $_POST['imagem'];

    $sql = "UPDATE carros SET 
        modelo = '$modelo', 
        marca= '$marca', preco= 
        '$preco', imagem= '$imagem' 
        WHERE id= '$id'";

    if($resultado = mysqli_query($conexao, $sql)){
        echo "<h2>Carro atualizado com sucesso!</h2> <a class='btn' style='margin-left: 42%' href='?pg=carros/list'>Voltar</a>";
    }else{
        echo "<h2>Erro ao atualizar carro.</h2>";
    }
}

?>
