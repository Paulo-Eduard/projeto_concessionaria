<?php

    require_once 'admin/config.inc.php';

    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $modelo = $_POST["modelo"];
        $marca = $_POST["marca"];
        $preco = $_POST["preco"];
        $imagem = $_POST["imagem"];
    }else{
        echo "<H2>Envio de dados não permitido</H2>";
    }

    $sql = "INSERT INTO carros (modelo, marca, preco, imagem)
            VALUES ('$modelo', '$marca', '$preco', '$imagem')";

    $inserir = mysqli_query($conexao, $sql);

    if($inserir) {
        echo "<H2>Cadastrado com sucesso</H2>";
        echo "<a href='?pg=carros/list'>Voltar</a>";
    }else{
        echo "Cadastrado não realizado.";
    }


?>