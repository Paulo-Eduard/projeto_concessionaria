<div class="container">
    <h2>Adicionar Carro</h2>
    <form method="POST" action='?pg=carros/carros-add'>
        <label>Modelo:</label>
        <input type="text" name="modelo" required>
        
        <label>Marca:</label>
        <input type="text" name="marca" required>
        
        <label>Preço:</label>
        <input type="number" step="0.01" name="preco" required>
        
        <label>Imagem:</label>
        <input type="text" name="imagem">
        
        <button type="submit">Adicionar</button>
        </form>
        </div>
        
        
        