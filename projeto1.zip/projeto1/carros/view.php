<?php

require "admin/config.inc.php";

$sql = "SELECT * FROM carros";
    $resultado = mysqli_query($conexao, $sql);

while($carro = mysqli_fetch_array($resultado)){
    echo"<div class='container'>
        <h2>"?><?php echo $carro['modelo']; ?> - <?php echo $carro['marca']; ?></h2>
        <img src="<?php echo $carro['imagem']; ?>" width="150px" height="150px">
        <p><strong>Preço:</strong> R$ <?php echo number_format($carro['preco'],2,",","."); ?></p>
        <a href="index.php">← Voltar</a>
    </div><?php
}
?>

