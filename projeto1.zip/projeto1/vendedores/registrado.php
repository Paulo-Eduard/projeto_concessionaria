<?php

    require_once "admin/config.inc.php";

    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $senha = $_POST["senha"];
    }else{
        echo "<H2>Envio de dados não permitido</H2>";
    }

    $sql = "INSERT INTO vendedores (nome, email, senha)
            VALUES ('$nome', '$email', '$senha')";

    $inserir = mysqli_query($conexao, $sql);

    if($inserir) {
        echo "<H2>Cadastrado com sucesso</H2>";
        echo "<a href='?pg=vendedores/login'>Fazer Login</a>";
    }else{
        echo "Cadastrado não realizado.";
    }