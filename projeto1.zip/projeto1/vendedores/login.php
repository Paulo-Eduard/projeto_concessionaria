<?php

session_start();


// Processar login
if(isset($_POST['login'])){
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $stmt = $conn->prepare("SELECT id, nome, senha FROM vendedores WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows === 1){
        $vendedor = $result->fetch_assoc();
        if(password_verify($senha, $vendedor['senha'])){
            $_SESSION['vendedor_id'] = $vendedor['id'];
            $_SESSION['vendedor_nome'] = $vendedor['nome'];
            header('Location: /projeto1/vendedores/dashboard.php');
            exit();
        } else {
            $erro = "Senha incorreta!";
        }
    } else {
        $erro = "Email não encontrado!";
    }
}
?>

<div class="container">
    <h2>Login do Vendedor</h2>

    <?php if(isset($erro)): ?>
        <p style="color:red;"><?php echo $erro; ?></p>
    <?php endif; ?>

    <form method="POST" action="?pg=carros/list">
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>

        <label for="senha">Senha:</label>
        <input type="password" name="senha" id="senha" required>

        <button type="submit" name="login" class="btn btn-primary" >Entrar</button>
    </form>

    <p>Não possui conta? <a href="register.php">Cadastre-se</a></p>
</div>

