<?php
session_start();
include '../includes/db.php';
include '../includes/header.php';

// Bloqueia acesso se não estiver logado
if(!isset($_SESSION['vendedor_id'])){
    header('Location: login.php');
    exit();
}
?>

<div class="container">
    <h2>Bem-vindo, <?php echo htmlspecialchars($_SESSION['vendedor_nome']); ?>!</h2>

    <div class="dashboard-actions">
        <a href="add_car.php" class="btn add-btn">Adicionar Carro</a>
        <a href="list_car.php" class="btn btn-primary">Ver Meus Carros</a>
        <a href="logout.php" class="btn logout-btn">Sair</a>
    </div>
</div>

<?php
include '../includes/footer.php';
?>
