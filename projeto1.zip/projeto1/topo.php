<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Concessionária</title>
    <link rel="stylesheet" href="assets/css/styles.css">

</head>
<body>
<header>
    <div class="top-nav">
        <h1>Concessionária</h1>
        <nav>
            <?php if(isset($_SESSION['vendedor_id'])): ?>
                <a href="../vendedores/dashboard.php">Dashboard</a>
                <a class="logout" href="../vendedores/logout.php">Sair</a>
            <?php elseif(isset($_SESSION['cliente_id'])): ?>
                <a href="../carros/list.php">Carros</a>
                <a class="logout" href="../clientes/logout.php">Sair</a>
            <?php else: ?>
                <a href="index.php">Home</a>
                <a href="?pg=clientes/login">Login Cliente</a>
                <a href="?pg=vendedores/login">Login Vendedor</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main>
